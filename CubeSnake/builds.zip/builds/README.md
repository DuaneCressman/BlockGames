# Cube Snake
<b>Author:</b> Duane Cressman</br>
<b>Date:</b> April 3, 2020</br>
<b>Language:</b> C#, Unity3D</br></br>
  This is still a prototype! </br>
  Rules: </br>-Use the WASD keys to change direction.</br>
  -Find and eat the silver balls to grow.</br>
  -Use the space bar to speed up.</br>
  -Your snake has a head light. Use it to help find where you are in relation to other objects.</br>
  -If you crash into your own body, that segment will die and become opaque and gray.</br>
  -If you crash into a dead body section or an obstical, you will loose half of your length.</br>
  -Press ESC to display the quit button.</br>
